function loadMods(game)
   JS.callJS([[console.log("Mod loader booting...");]])

    require "mods.example.main"
    loadExampleMod(game)

    JS.callJS([[console.log("Loaded all mods!");]])
end