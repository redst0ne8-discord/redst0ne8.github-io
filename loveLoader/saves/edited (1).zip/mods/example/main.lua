require "globals"
require "challenges"
require "game"
require "js"

function loadExampleMod(game)
    JS.callJS([[console.log("applying mod");]])

    table.insert(game.CHALLENGES, {
        name = "The Debug",
        id = "c_debug_1",
        rules = {
            custom = {},
            modifiers = {
                {id = 'consumable_slots', value = 3},
            }
        },
        deck = {
            type = "Challenge Deck",
            cards = {
                {s = 'H', r = 'A'}
            }
        },
        jokers = {
            {
                id = "j_dna",
                edition = "negative"
            }
        },
        consumeables = {
            {id="c_pluto"},
            {id="c_fool"},
            {id="c_fool"}
        },
        vouchers = {},
        restrictions = {
            banned_cards = {
                {id="c_familiar"},
                {id="c_grim"},
                {id="c_incantation"},
                {id="c_cryptid"},
                {id="j_marble"},
                {id="j_certificate"},

                {id = 'p_standard_normal_1', ids = {
                    'p_standard_normal_1','p_standard_normal_2','p_standard_normal_3','p_standard_normal_4','p_standard_jumbo_1','p_standard_jumbo_2','p_standard_mega_1','p_standard_mega_2',
                }},

                {id="v_magic_trick"},
                {id="v_illusion"},
            },
            banned_tags = {
                {id = 'tag_standard'},
            },
            banned_other = {}
        }
    })


    table.insert(game.CHALLENGES, {
        name = "The Big One",
        id = "c_big",
        rules = {
            custom = {},
            modifiers = {
                {id = 'joker_slots', value = 999},
            }
        },
        deck = {
            type = "Challenge Deck",
        },
        jokers = {},
        consumeables = {},
        vouchers = {},
        restrictions = {
            banned_cards = {},
            banned_tags = {},
            banned_other = {}
        }
    })




    table.insert(game.CHALLENGES, {
        name = "Riff Raff",
        id = "c_riff_raff",
        rules = {
            custom = {
                {id = 'no_shop_jokers'},
            },
            modifiers = {}
        },
        deck = {
            type = "Challenge Deck",
        },
        jokers = {
            {
                id = "j_riff_raff"
            }
        },
        consumeables = {},
        vouchers = {},
        restrictions = {
            banned_cards = {
                {id = 'c_judgement'},
                {id = 'c_wraith'},
                {id = 'c_soul'},
                {id = 'p_buffoon_normal_1', ids = {
                    'p_buffoon_normal_1','p_buffoon_normal_2','p_buffoon_jumbo_1','p_buffoon_mega_1',
                }},
            },
            banned_tags = {
                {id = 'tag_rare'},
                {id = 'tag_uncommon'},
                {id = 'tag_holo'},
                {id = 'tag_polychrome'},
                {id = 'tag_negative'},
                {id = 'tag_foil'},
                {id = 'tag_buffoon'},
                {id = 'tag_top_up'},

            },
            banned_other = {}
        }
    })



    game.P_CENTERS.b_joking = {
        name = "Joking Deck",
        stake = 1, demo = false,
        unlocked = true,
        order = 16,
        pos = {x=0,y=3},
        set = "Back",
        config = {
            ante_scaling = 0,
            joker_slot = 3
        },
        discovered = true,
        start_discovered = true
    }

    game.P_CENTERS.b_all = {
        name = "Everything Deck",
        stake = 1, demo = false,
        unlocked = true,
        order = 17,
        pos = {x=0,y=3},
        set = "Back",
        config = {
            hands = 1 - 1,
            dollars = 10,
            extra_hand_bonus = 2,
            extra_discard_bonus = 1,
            no_interest = true,
            consumables = {'c_fool', 'c_fool', 'c_hex'},
            consumable_slot = 0,
            spectral_rate = 2,
            remove_faces = true,
            vouchers = {'v_tarot_merchant','v_planet_merchant', 'v_overstock_norm', 'v_telescope', 'v_crystal_ball'},
            hand_size = 2,
            ante_scaling = 2 + 1 + 1,
            randomize_rank_suit = true,
            joker_slot = 1 - 1,
        },
        discovered = true,
        start_discovered = true
    }

    -- game.P_BLINDS.bl_rival = {
    --     name = 'Rival Battle',
    --     demo = true,
    --     defeated = true,
    --     order = 31,
    --     dollars = 5,
    --     mult = 0,
    --     vars = {},
    --     debuff = {},
    --     pos = { x=0, y=31 },
    --     boss = { showdown = false, min = -10, max = -10 },
    --     boss_colour = HEX('f3cd4a'),
    --     discovered = true,
    --     alerted = false,
    -- }


--     table.insert(game.CHALLENGES, {
--         name = "Rival",
--         id = "c_rival_1",
--         rules = {
--             custom = {
--                 {id = 'rival'},
--             },
--             modifiers = {
--                 {id = 'consumable_slots', value = 2},
--                 {id = 'dollars', value = 25},
--                 {id = 'hand_size', value = 8},
--                 {id = 'hands', value = 4},
--                 {id = 'discards', value = 4},
--                 {id = 'joker_slots', value = 5},
--             }
--         },
--         deck = {
--             type = "Challenge Deck",
--         },
--         jokers = {},
--         consumeables = {},
--         vouchers = {},
--         restrictions = {
--             banned_cards = {
--                 {id="j_luchador"},
--                 {id="j_mr_bones"},
--                 {id="j_matador"},
--                 {id="j_chicot"},

--                 {id="v_retcon"},
--                 {id="v_directors_cut"},
--             },
--             banned_tags = {
--                 {id = 'tag_boss'},
--             },
--             banned_other = {
-- --                {id = 'bl_ox', type = 'blind'},
-- --                {id = 'bl_hook', type = 'blind'},
-- --                {id = 'bl_mouth', type = 'blind'},
-- --                {id = 'bl_fish', type = 'blind'},
-- --                {id = 'bl_club', type = 'blind'},
-- --                {id = 'bl_manacle', type = 'blind'},
-- --                {id = 'bl_tooth', type = 'blind'},
-- --                {id = 'bl_wall', type = 'blind'},
-- --                {id = 'bl_house', type = 'blind'},
-- --                {id = 'bl_mark', type = 'blind'},
-- --                {id = 'bl_final_bell', type = 'blind'},
-- --                {id = 'bl_wheel', type = 'blind'},
-- --                {id = 'bl_arm', type = 'blind'},
-- --                {id = 'bl_psychic', type = 'blind'},
-- --                {id = 'bl_goad', type = 'blind'},
-- --                {id = 'bl_water', type = 'blind'},
-- --                {id = 'bl_eye', type = 'blind'},
-- --                {id = 'bl_plant', type = 'blind'},
-- --                {id = 'bl_needle', type = 'blind'},
-- --                {id = 'bl_head', type = 'blind'},
-- --                {id = 'bl_final_leaf', type = 'blind'},
-- --                {id = 'bl_final_vessel', type = 'blind'},
-- --                {id = 'bl_serpent', type = 'blind'},
-- --                {id = 'bl_pillar', type = 'blind'},
-- --                {id = 'bl_flint', type = 'blind'},
-- --                {id = 'bl_final_heart', type = 'blind'},
-- --                {id = 'bl_window', type = 'blind'},
-- --                {id = 'bl_final_acorn', type = 'blind'},
--             }
--         }
--     })

    game.SETTINGS.GAMESPEED = 4
    game.SETTINGS.screenshake = 0

    game.SETTINGS.tutorial_complete = true
    game.PROFILES[game.SETTINGS.profile].challenges_unlocked = #game.CHALLENGES

    game.SETTINGS.colourblind_option = true

    local new_colour_proto = game.C["SO_"..(game.SETTINGS.colourblind_option and 2 or 1)]
    game.C.SUITS.Hearts = new_colour_proto.Hearts
    game.C.SUITS.Diamonds = new_colour_proto.Diamonds
    game.C.SUITS.Spades = new_colour_proto.Spades
    game.C.SUITS.Clubs = new_colour_proto.Clubs

    local original_update = love.update
    local p_was_down = false

    local unlockedAll = false

    function love.update(dt)
        original_update(dt)

        if game.PROFILES[game.SETTINGS.profile] and not unlockedAll then
            game.FUNCS.unlock_all()
            unlockedAll = true
        end


        game:save_settings()
        game:save_progress()

        if not game.GAME then return end

            -- game.GAME.win_ante = game.GAME.round_scores.furthest_ante.amt + 1

            -- local p_is_down = love.keyboard.isDown("p")

            -- if (game.GAME.challenge == "c_rival_1") then
            --     game.GAME.round_resets.blind_choices.Boss = "bl_rival"
            --     if (game.GAME.blind.boss) then
            --         game.GAME.blind.chips = 67
            --         game.GAME.blind.chip_text = number_format(game.GAME.blind.chips)
            --         game.GAME.blind.chips = math.huge
            --     end
            -- end

            -- if p_is_down and not p_was_down then


            --     game.GAME.chips = game.GAME.chips * 2
            --     print(game.GAME.challenge)

            -- end

            -- p_was_down = p_is_down

            
        end



end